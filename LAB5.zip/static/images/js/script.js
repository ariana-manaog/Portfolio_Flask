// Mobile Navigation Toggle
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');

if (hamburger) {
    hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
    });
}

// Close mobile menu when clicking on a link
document.querySelectorAll('.nav-link').forEach(n => n.addEventListener('click', () => {
    hamburger.classList.remove('active');
    navMenu.classList.remove('active');
}));

// Circle Area Calculator
const circleForm = document.getElementById('circleForm');
if (circleForm) {
    circleForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const radius = document.getElementById('radius').value;
        const resultDiv = document.getElementById('result');
        
        if (!radius || radius <= 0) {
            resultDiv.innerHTML = '<p style="color: red;">Please enter a valid positive radius</p>';
            return;
        }

        try {
            const response = await fetch('/calculate_circle', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ radius: parseFloat(radius) })
            });

            const data = await response.json();
            resultDiv.innerHTML = `<p style="color: green;">Area: ${data.area} square units</p>`;
        } catch (error) {
            resultDiv.innerHTML = '<p style="color: red;">Error calculating area</p>';
        }
    });
}

// Triangle Area Calculator
const triangleForm = document.getElementById('triangleForm');
if (triangleForm) {
    triangleForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const base = document.getElementById('base').value;
        const height = document.getElementById('height').value;
        const resultDiv = document.getElementById('result');
        
        if (!base || base <= 0 || !height || height <= 0) {
            resultDiv.innerHTML = '<p style="color: red;">Please enter valid positive values for base and height</p>';
            return;
        }

        try {
            const response = await fetch('/calculate_triangle', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ 
                    base: parseFloat(base), 
                    height: parseFloat(height) 
                })
            });

            const data = await response.json();
            resultDiv.innerHTML = `<p style="color: green;">Area: ${data.area} square units</p>`;
        } catch (error) {
            resultDiv.innerHTML = '<p style="color: red;">Error calculating area</p>';
        }
    });
}

// Contact Form Handler
const contactForm = document.getElementById('contactForm');
if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        alert('Thank you for your message! This is a demo form - in a real application, this would send your message.');
        contactForm.reset();
    });
}

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});