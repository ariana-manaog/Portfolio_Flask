from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/profile')
def profile():
    return render_template('profile.html')

@app.route('/works')
def works():
    return render_template('works.html')

@app.route('/touppercase', methods=['GET', 'POST'])
def touppercase():
    result = None
    if request.method == 'POST':
        input_string = request.form.get('inputString', '')
        result = input_string.upper()
    return render_template('touppercase.html', result=result)

@app.route('/contact')
def contact():
    return render_template('contacts.html')

# New routes for calculations & Conversions
@app.route('/circle')
def circle():
    return render_template('circle.html')

@app.route('/triangle')
def triangle():
    return render_template('triangle.html')

@app.route('/calculate_circle', methods=['POST'])
def calculate_circle():
    data = request.get_json()
    radius = float(data['radius'])
    area = 3.14159 * radius * radius
    return jsonify({'area': round(area, 2)})

@app.route('/calculate_triangle', methods=['POST'])
def calculate_triangle():
    data = request.get_json()
    base = float(data['base'])
    height = float(data['height'])
    area = 0.5 * base * height
    return jsonify({'area': round(area, 2)})

def infix_to_postfix(expression):
    precedence = {'+': 1, '-': 1, '*': 2, '/': 2, '^': 3}
    
    def is_operator(char):
        return char in precedence
    
    def has_higher_precedence(op1, op2):
        return precedence[op1] >= precedence[op2]
    
    stack = []
    output = []
    
    for char in expression.replace(" ", ""):
        if char.isalnum(): 
            output.append(char)
        elif char == '(':
            stack.append(char)
        elif char == ')':
            while stack and stack[-1] != '(':
                output.append(stack.pop())
            stack.pop()  # Remove '('
        elif is_operator(char):
            while (stack and stack[-1] != '(' and 
                   has_higher_precedence(stack[-1], char)):
                output.append(stack.pop())
            stack.append(char)
    
    while stack:
        output.append(stack.pop())
    
    return ' '.join(output)

@app.route('/infixtopostfix', methods=['GET', 'POST'])
def infixtopostfix():
    result = None
    original_expression = None
    if request.method == 'POST':
        original_expression = request.form.get('infixExpression', '')
        result = infix_to_postfix(original_expression)
    return render_template('infixtopostfix.html', result=result, original_expression=original_expression)



if __name__ == "__main__":
    app.run(debug=True)