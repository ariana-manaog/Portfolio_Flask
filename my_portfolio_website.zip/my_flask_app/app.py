from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/profile')
def profile():
    return render_template('profile.html')

@app.route('/touppercase', methods=['GET', 'POST'])
def touppercase():
    result = None
    if request.method == 'POST':
        input_string = request.form.get('inputString', '')
        result = input_string.upper()
    return render_template('touppercase.html', result=result)

@app.route('/contact')
def contact():
    return render_template('contacts.html')

# New routes for area calculations
@app.route('/circle')
def circle():
    return render_template('circle.html')

@app.route('/triangle')
def triangle():
    return render_template('triangle.html')

# API endpoints for calculations
@app.route('/calculate_circle', methods=['POST'])
def calculate_circle():
    data = request.get_json()
    radius = float(data['radius'])
    area = 3.14159 * radius * radius
    return jsonify({'area': round(area, 2)})

@app.route('/calculate_triangle', methods=['POST'])
def calculate_triangle():
    data = request.get_json()
    base = float(data['base'])
    height = float(data['height'])
    area = 0.5 * base * height
    return jsonify({'area': round(area, 2)})

if __name__ == "__main__":
    app.run(debug=True)